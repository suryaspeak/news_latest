import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-last',
  templateUrl: './last.page.html',
  styleUrls: ['./last.page.scss'],
})
export class LastPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  exit(){
    navigator['app'].exitApp();
  }
}
