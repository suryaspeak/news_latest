import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-value',
  templateUrl: './value.page.html',
  styleUrls: ['./value.page.scss'],
})
export class ValuePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
